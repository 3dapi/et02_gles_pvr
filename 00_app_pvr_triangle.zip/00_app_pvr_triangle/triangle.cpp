
#include <stdio.h>

#include <GLES/egl.h>
#include <GLES/gl.h>
#include <GLES/glesext.h>


static float vtx_pos[] =
{
	-0.94f, -0.94f, 0.0f,
	 0.94f, -0.94f, 0.0f,
	 0.94f,  0.94f, 0.0f,
	-0.94f,  0.94f, 0.0f
};

static float vtx_dif[] =
{
	 1.0f,   0.0f,  1.0f,  1.0f,
	 1.0f,   0.0f,  0.0f,  1.0f,
	 0.0f,   1.0f,  0.0f,  1.0f,
	 0.0f,   1.0f,  1.0f,  1.0f,
};


int ogl_app_init()
{
	return 0;
}


int ogl_app_destroy()
{
	return 0;
}

int ogl_app_draw()
{
	glClearColor(0.0F, 0.4F, 0.6F, 1.0F);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glFrontFace(GL_CCW);
	glDisable(GL_LIGHTING);


	//glColor4f(1.0F, 0.0F, 0.0F, 0.3F);


	glEnableClientState(GL_COLOR_ARRAY);	glColorPointer   (4, GL_FLOAT, 0, &vtx_dif[0]);
	glEnableClientState(GL_VERTEX_ARRAY);	glVertexPointer  (3, GL_FLOAT, 0, &vtx_pos[0]);

	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);

	return 0;
}


