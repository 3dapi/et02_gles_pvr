
#include <stdio.h>

#include <GLES/egl.h>
#include <GLES/gl.h>
#include <GLES/glesext.h>


extern int LoadTGAFile(int* oW, int* oH, int* oD, unsigned char** oB, char *sFile);

static GLuint	m_nTexD;
static GLuint	m_nTexL;

static float vtx_pos[] =
{
	-0.94f, -0.94f, 0.0f,
	 0.94f, -0.94f, 0.0f,
	 0.94f,  0.94f, 0.0f,
	-0.94f,  0.94f, 0.0f
};

static float vtx_tex[] =
{
	0.0f, 0.0f,
	1.0f, 0.0f,
	1.0f, 1.0f,
	0.0f, 1.0f
};



int ogl_app_init()
{
	int hr = 0;

	{
		int				nImgW = 0;
		int				nImgH = 0;
		int				nImgD = 0;
		unsigned char*	pPxl  = NULL;

		hr = LoadTGAFile(&nImgW, &nImgH, &nImgD, &pPxl, "_media/texture/stones.tga");
		if(0>hr)
			return -1;

		glGenTextures (1,&m_nTexD);
		glBindTexture  (GL_TEXTURE_2D, m_nTexD);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, nImgW, nImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
		glBindTexture (GL_TEXTURE_2D, 0);
		delete pPxl;
	}

	{
		int				nImgW = 256;
		int				nImgH = 256;
		int				nImgD = 1;
		int				size  = nImgW * nImgH * nImgH;
		unsigned char*	pPxl  = new unsigned char[size]{};

		FILE* fp = fopen("_media/texture/env0.raw", "rb");
		if(NULL == fp)
			return -1;

		int r = fread(pPxl, sizeof(unsigned char), size, fp);
		fclose(fp);


		unsigned char*	pTp = new unsigned char[nImgW]{};
		unsigned char*	pT1 = NULL;
		unsigned char*	pT2 = NULL;

		for(int i=0; i<nImgH/2; ++i)
		{
			pT1 = &pPxl[nImgW * i             ];
			pT2 = &pPxl[nImgW * (nImgH -1 - i)];

			memcpy(pTp, pT1, nImgW);
			memcpy(pT1, pT2, nImgW);
			memcpy(pT2, pTp, nImgW);
		}
		delete[] pTp;

		glGenTextures  (1,&m_nTexL);
		glBindTexture  (GL_TEXTURE_2D, m_nTexL);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexImage2D   (GL_TEXTURE_2D, 0, GL_ALPHA, nImgW, nImgH, 0, GL_ALPHA, GL_UNSIGNED_BYTE, pPxl);
		glBindTexture  (GL_TEXTURE_2D, 0);
		delete[] pPxl;
	}

	return 0;
}


int ogl_app_destroy()
{
	if(m_nTexD)
	{
		glDeleteTextures(1, &m_nTexD);
		m_nTexD = 0;
	}

	if(m_nTexL)
	{
		glDeleteTextures(1, &m_nTexL);
		m_nTexL = 0;
	}

	return 0;
}

int ogl_app_draw()
{
	glClearColor(0.0F, 0.4F, 0.6F, 1.0F);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glFrontFace(GL_CCW);
	glDisable(GL_LIGHTING);


	glColor4f(1.0F, 1.0F, 0.0F, 0.3F);

	glActiveTexture(GL_TEXTURE0 + 0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, m_nTexD);


	glClientActiveTexture(GL_TEXTURE0 + 0);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer(2, GL_FLOAT, 0, &vtx_tex[0]);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	//glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	//glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
	//glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_TEXTURE);
	//glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE1_RGB, GL_CONSTANT);

	//glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);
	//glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_CONSTANT);
	//glTexEnvf(GL_TEXTURE_ENV, GL_OPERAND0_ALPHA, GL_SRC_ALPHA);

	glActiveTexture(GL_TEXTURE0 + 1);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, m_nTexL);


	glClientActiveTexture(GL_TEXTURE0 + 1);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer(2, GL_FLOAT, 0, &vtx_tex[0]);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE);
	glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_RGB, GL_MODULATE);
	glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_RGB, GL_PREVIOUS);

	glTexEnvf(GL_TEXTURE_ENV, GL_COMBINE_ALPHA, GL_REPLACE);
	glTexEnvf(GL_TEXTURE_ENV, GL_SOURCE0_ALPHA, GL_TEXTURE);


	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer  (3, GL_FLOAT, 0, &vtx_pos[0]);
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

	glDisableClientState(GL_VERTEX_ARRAY);


	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);


	glActiveTexture(GL_TEXTURE0);
	glDisable(GL_TEXTURE_2D);
	glClientActiveTexture(GL_TEXTURE0);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

	return 0;
}


