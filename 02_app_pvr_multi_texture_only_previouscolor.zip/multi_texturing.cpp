
#include <stdio.h>

#include <GLES/egl.h>
#include <GLES/gl.h>
#include <GLES/glext.h>


int CreateTextureFromTga(const char* file, int filterMinMag = 0x2601, int wrapMode = 0x812F);
int CreateTextureFromRaw(const char* file, int filterMinMag = 0x2601, int wrapMode = 0x812F);
int DeleteTexture(int count, int* texId);

static int	oid_color;
static int	oid_alpha;

static float vtx_pos0[] =
{
	-0.94f, -0.94f,
	-0.01f, -0.94f,
	-0.01f,  0.94f,
	-0.94f,  0.94f
};

static float vtx_pos1[] =
{
	 0.01f, -0.94f,
	 0.94f, -0.94f,
	 0.94f,  0.94f,
	 0.01f,  0.94f
};

static float vtx_tex[] =
{
	0.0f, 0.0f,
	1.0f, 0.0f,
	1.0f, 1.0f,
	0.0f, 1.0f
};

static float vtx_color[] =
{
	1.0f, 0.0f, 0.0f, 1.0f,
	0.0f, 1.0f, 0.0f, 1.0f,
	0.0f, 0.0f, 1.0f, 1.0f,
	1.0f, 0.0f, 1.0f, 1.0f,
};

static int max_stack_modelview  = 0;
static int max_stack_projection = 0;
static int max_stack_texture    = 0;

int ogl_app_init()
{
	glGetIntegerv(GL_MAX_MODELVIEW_STACK_DEPTH , &max_stack_modelview);
	glGetIntegerv(GL_MAX_PROJECTION_STACK_DEPTH, &max_stack_projection);
	glGetIntegerv(GL_MAX_TEXTURE_STACK_DEPTH   , &max_stack_texture);


	oid_color = CreateTextureFromTga("_media/texture/stones.tga");
	if(0>oid_color)
		return -1;

	oid_alpha = CreateTextureFromRaw("_media/texture/env0.raw");
	if(0>oid_alpha)
		return -1;

	return 0;
}


int ogl_app_destroy()
{
	if(oid_color)
	{
		DeleteTexture(1, &oid_color);
		oid_color = 0;
	}

	if(oid_alpha)
	{
		DeleteTexture(1, &oid_alpha);
		oid_alpha = 0;
	}

	return 0;
}

int ogl_app_draw()
{
	glClearColor(0.0F, 0.4F, 0.6F, 1.0F);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glFrontFace(GL_CCW);
	glDisable(GL_LIGHTING);


	// for saving render state
	int prev_param1[8][4]{};

	//# multi-texture 0
	{
		glActiveTexture(GL_TEXTURE0 + 0);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, oid_color);

		glClientActiveTexture(GL_TEXTURE0 + 0);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);	glTexCoordPointer(2, GL_FLOAT, 0, &vtx_tex  [0]);

		//# multi-texture 1
		{
			glActiveTexture(GL_TEXTURE0 + 1);
			glEnable(GL_TEXTURE_2D);
			glBindTexture(GL_TEXTURE_2D, oid_alpha);

			glGetTexEnviv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , &prev_param1[0][0]);
			glGetTexEnviv(GL_TEXTURE_ENV, GL_COMBINE_RGB      , &prev_param1[1][0]);
			glGetTexEnviv(GL_TEXTURE_ENV, GL_SRC0_RGB         , &prev_param1[2][0]);

			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , GL_COMBINE);
			glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB      , GL_REPLACE);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB         , GL_PREVIOUS);

			glClientActiveTexture(GL_TEXTURE0 + 1);
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);	glTexCoordPointer(2, GL_FLOAT, 0, &vtx_tex  [0]);

			glEnableClientState(GL_VERTEX_ARRAY);			glVertexPointer  (2, GL_FLOAT, 0, &vtx_pos0 [0]);
			glEnableClientState(GL_COLOR_ARRAY);			glColorPointer   (4, GL_FLOAT, 0, &vtx_color[0]);
			glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

			glDisableClientState(GL_VERTEX_ARRAY);
			glDisableClientState(GL_COLOR_ARRAY);
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);

			glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE , prev_param1[0][0]);
			glTexEnvi(GL_TEXTURE_ENV, GL_COMBINE_RGB      , prev_param1[1][0]);
			glTexEnvi(GL_TEXTURE_ENV, GL_SRC0_RGB         , prev_param1[2][0]);

			glBindTexture(GL_TEXTURE_2D, 0);
			glDisable(GL_TEXTURE_2D);
		}
	}

	{
		glActiveTexture(GL_TEXTURE0 + 0);
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, oid_color);

		glEnableClientState(GL_TEXTURE_COORD_ARRAY);	glTexCoordPointer(2, GL_FLOAT, 0, &vtx_tex  [0]);
		glEnableClientState(GL_VERTEX_ARRAY);			glVertexPointer  (2, GL_FLOAT, 0, &vtx_pos1 [0]);
		glEnableClientState(GL_COLOR_ARRAY);			glColorPointer   (4, GL_FLOAT, 0, &vtx_color[0]);
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_COLOR_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);

		glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}

	return 0;
}


