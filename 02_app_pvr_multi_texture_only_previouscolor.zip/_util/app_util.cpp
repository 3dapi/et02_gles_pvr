
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <GLES/egl.h>
#include <GLES/gl.h>
#include <GLES/glext.h>


struct TGAHEADER
{
	unsigned char	ImgT;				// imageTypeCode
	short			ImgW;				// Width
	short			ImgH;				// Height
	unsigned char	ImgB;				// Bit Count
};

int LoadTGA(int* oW, int* oH, int* oD, unsigned char** oB, const char *sFile)
{
	FILE*			fp;
	unsigned char	charBad;					// garbage data
	short			sintBad;					// garbage data
	long			imageSize;					// size of TGA image

	TGAHEADER		Tga;

	int				nImgB;
	unsigned char*	pPxlT = NULL;

	// open the TGA file
	fp = fopen(sFile, "rb");

	if (!fp)
		return -1;

	// read first two bytes of garbage
	fread(&charBad, sizeof(unsigned char), 1, fp);
	fread(&charBad, sizeof(unsigned char), 1, fp);

	// read in the image type
	fread(&Tga.ImgT, sizeof(Tga.ImgT), 1, fp);

	// for our purposes, the image type should be either a 2 or a 3
	if ((Tga.ImgT != 2) && (Tga.ImgT != 3))
	{
		fclose(fp);
		return -1;
	}

	// read 13 bytes of garbage data
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&charBad, sizeof(unsigned char ), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);

	// read image dimensions
	fread(&Tga.ImgW, sizeof(short), 1, fp);
	fread(&Tga.ImgH, sizeof(short), 1, fp);

	// read bit depth
	fread(&Tga.ImgB, sizeof(unsigned char), 1, fp);

	// read garbage
	fread(&charBad, sizeof(unsigned char), 1, fp);


	// colormode -> 3 = BGR, 4 = BGRA
	nImgB		= Tga.ImgB>>3;
	imageSize	= Tga.ImgW * Tga.ImgH * nImgB;
	pPxlT		= new unsigned char[imageSize];

	fread(pPxlT, sizeof(unsigned char), imageSize, fp);
	fclose(fp);

	if(oW) *oW	= Tga.ImgW;
	if(oH) *oH	= Tga.ImgH;
	if(oD) *oD	= 4;

	unsigned char* m_pPxl	= new unsigned char[Tga.ImgW * Tga.ImgH* 4];
	*oB = m_pPxl;

	// BGR
	if(3 == nImgB)
	{
		for(int y=0; y<Tga.ImgH; ++y)
		{
			for(int x=0; x<Tga.ImgW; ++x)
			{
				int n1 = (y*Tga.ImgW + x)* 3;
				int n2 = (y*Tga.ImgW + x)* 4;

				unsigned char B = pPxlT[n1+0];
				unsigned char G = pPxlT[n1+1];
				unsigned char R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA
	else if(4 == nImgB)
	{
		for(int y=0; y<Tga.ImgH; ++y)
		{
			for(int x=0; x<Tga.ImgW; ++x)
			{
				int n1 = (y*Tga.ImgW + x)* 4;
				int n2 = (y*Tga.ImgW + x)* 4;

				unsigned char B = pPxlT[n1+0];
				unsigned char G = pPxlT[n1+1];
				unsigned char R = pPxlT[n1+2];
				unsigned char A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pPxlT;
	return 0;
}


int LoadRAW(int* oW, int* oH, int* oD, unsigned char** oB, const char *sFile)
{
	int				imgW = 0;
	int				size = 0;
	unsigned char*	pPxl = NULL;

	FILE* fp = fopen(sFile, "rb");
	if(NULL == fp)
		return -1;

	fseek(fp, 0, SEEK_END);
	size = (int)ftell(fp);
	fseek(fp, 0, SEEK_SET);

	imgW = (int)sqrt(size+0.5);

	pPxl = new unsigned char[size]{};
	int r = fread(pPxl, sizeof(unsigned char), size, fp);
	fclose(fp);

	unsigned char*	pTp = new unsigned char[imgW]{};
	unsigned char*	pT1 = NULL;
	unsigned char*	pT2 = NULL;

	for(int y=0; y<imgW/2; ++y)
	{
		pT1 = pPxl + imgW * y;
		pT2 = pPxl + imgW * (imgW -1 - y);

		memcpy(pTp, pT1, imgW);
		memcpy(pT1, pT2, imgW);
		memcpy(pT2, pTp, imgW);
	}
	delete[] pTp;

	if(oW) *oW = imgW;
	if(oH) *oH = imgW;
	if(oD) *oD = 1;
	if(oB) *oB = pPxl;

	return 0;
}


int CreateTextureFromTga(const char* file, int filterMinMag = 0x2601, int wrapMode = 0x812F)
{
	int				texId = 0;

	int				nImgW = 0;
	int				nImgH = 0;
	int				nImgD = 0;
	unsigned char*	pPxl  = NULL;

	int hr = LoadTGA(&nImgW, &nImgH, &nImgD, &pPxl, file);
	if(0>hr)
		return -1;

	glGenTextures(1, (GLuint *)&texId);
	if(0 >= texId)
		return -1;

	int tex_prev = 0;											// previous binding texture
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex_prev);			// get the stored texture

	glBindTexture(GL_TEXTURE_2D, texId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filterMinMag);//, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filterMinMag);//, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S    , wrapMode    );//, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T    , wrapMode    );//, GL_CLAMP_TO_EDGE);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, nImgW, nImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);

	glBindTexture(GL_TEXTURE_2D, tex_prev);
	delete[] pPxl;

	return (int)texId;
}

int CreateTextureFromRaw(const char* file, int filterMinMag = 0x2601, int wrapMode = 0x812F)
{
	int				texId = 0;

	int				nImgW = 0;
	int				nImgH = 0;
	int				nImgD = 0;
	unsigned char*	pPxl  = NULL;

	int hr = LoadRAW(&nImgW, &nImgH, &nImgD, &pPxl, file);
	if(0>hr)
		return -1;

	glGenTextures(1, (GLuint *)&texId);
	if(0 >= texId)
		return -1;

	int tex_prev = 0;											// previous binding texture
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex_prev);			// get the stored texture

	glBindTexture(GL_TEXTURE_2D, texId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filterMinMag);//, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filterMinMag);//, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S    , wrapMode    );//, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T    , wrapMode    );//, GL_CLAMP_TO_EDGE);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, nImgW, nImgH, 0, GL_ALPHA, GL_UNSIGNED_BYTE, pPxl);

	glBindTexture(GL_TEXTURE_2D, tex_prev);
	delete[] pPxl;

	return (int)texId;
}

int DeleteTexture(int count, int* texId)
{
	glDeleteTextures(count, (const GLuint *)texId);
	return 0;
}


