
#include <stdio.h>

struct TGAHEADER
{
	unsigned char	ImgT;				// imageTypeCode
	short			ImgW;				// Width
	short			ImgH;				// Height
	unsigned char	ImgB;				// Bit Count
};

int LoadTGAFile(int* oW, int* oH, int* oD, unsigned char** oB, char *sFile)
{
	FILE*			fp;
	unsigned char	charBad;					// garbage data
	short			sintBad;					// garbage data
	long			imageSize;					// size of TGA image

	TGAHEADER		Tga;

	int				nImgB;
	unsigned char*	pPxlT = NULL;

	// open the TGA file
	fp = fopen(sFile, "rb");

	if (!fp)
		return -1;

	// read first two bytes of garbage
	fread(&charBad, sizeof(unsigned char), 1, fp);
	fread(&charBad, sizeof(unsigned char), 1, fp);

	// read in the image type
	fread(&Tga.ImgT, sizeof(Tga.ImgT), 1, fp);

	// for our purposes, the image type should be either a 2 or a 3
	if ((Tga.ImgT != 2) && (Tga.ImgT != 3))
	{
		fclose(fp);
		return -1;
	}

	// read 13 bytes of garbage data
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&charBad, sizeof(unsigned char ), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);
	fread(&sintBad, sizeof(short), 1, fp);

	// read image dimensions
	fread(&Tga.ImgW, sizeof(short), 1, fp);
	fread(&Tga.ImgH, sizeof(short), 1, fp);

	// read bit depth
	fread(&Tga.ImgB, sizeof(unsigned char), 1, fp);

	// read garbage
	fread(&charBad, sizeof(unsigned char), 1, fp);


	// colormode -> 3 = BGR, 4 = BGRA
	nImgB		= Tga.ImgB>>3;
	imageSize	= Tga.ImgW * Tga.ImgH * nImgB;
	pPxlT		= new unsigned char[imageSize];

	fread(pPxlT, sizeof(unsigned char), imageSize, fp);
	fclose(fp);

	*oW	= Tga.ImgW;
	*oH	= Tga.ImgH;
	*oD	= 4;

	unsigned char* m_pPxl	= new unsigned char[Tga.ImgW * Tga.ImgH* 4];
	*oB = m_pPxl;

	// BGR
	if(3 == nImgB)
	{
		for(int y=0; y<Tga.ImgH; ++y)
		{
			for(int x=0; x<Tga.ImgW; ++x)
			{
				int n1 = (y*Tga.ImgW + x)* 3;
				int n2 = (y*Tga.ImgW + x)* 4;

				unsigned char B = pPxlT[n1+0];
				unsigned char G = pPxlT[n1+1];
				unsigned char R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA
	else if(4 == nImgB)
	{
		for(int y=0; y<Tga.ImgH; ++y)
		{
			for(int x=0; x<Tga.ImgW; ++x)
			{
				int n1 = (y*Tga.ImgW + x)* 4;
				int n2 = (y*Tga.ImgW + x)* 4;

				unsigned char B = pPxlT[n1+0];
				unsigned char G = pPxlT[n1+1];
				unsigned char R = pPxlT[n1+2];
				unsigned char A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pPxlT;

	return 0;
}


